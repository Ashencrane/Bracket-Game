'''
Created on Apr 21, 2022

@author: skywi
'''

class Contestors:
    '''
    Takes in a file object and returns a list containing the contestors. 
    '''

    def __init__(self, file):
        f = open(file).readlines()
        self.c = [line.strip() for line in f]
        if len(self.c) % 4 != 0:
            raise AssertionError('Must need the total items be a multiple of 4')
    
    def get_contestors(self):
        return self.c
    
    def get_game_state(self):
        if len(self.c) == 1: 
            return 1
        else:
            return 0
    def remove(self, item):
        self.c.remove(item)
        
    def update(self, item):
        for i in item:
            self.c.remove(i)
        
        