'''
Created on Apr 21, 2022

@author: skywi
'''
from Contestors import Contestors

if __name__ == '__main__':
    print(f'Welcome to Bracket!')
    file = input('Please input text file: ')
    c = Contestors(file)
    round = 1
    running = True 
    while running: 
        while c.get_game_state() != 1: 
            if len(c.get_contestors()) == 2: 
                i = 0
                print(f'-Final Round-')
                to_remove = []
                ans = input(f'{c.get_contestors()[i]} vs {c.get_contestors()[i+1]} (</>): ')
                if ans == '>':
                    c.remove(c.get_contestors()[i])
                elif ans == '<':
                    c.remove(c.get_contestors()[i+1])
                
            else:
                print(f'-Round {round}-')
                i = 0
                to_remove = []
                while i + 1 < len(c.get_contestors()):
                    ans = input(f'{c.get_contestors()[i]} vs {c.get_contestors()[i+1]} (</>): ')
                    if ans == '>':
                        to_remove.append(c.get_contestors()[i])
                    elif ans == '<':
                        to_remove.append(c.get_contestors()[i+1])
                    i += 2
                print('')
                c.update(to_remove)
            
            round += 1
        print(f'\nWinner: {c.get_contestors()[0]}')
        re = input(f'Would you like to do another game?(Yes/No): ')
        if re == 'No':
            running = False 
    print('End')
    
